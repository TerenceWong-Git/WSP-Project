// This is your test secret API key.
const stripe = require('stripe')('sk_test_51M7B7EGr4TbCHLmDU9hwEpc6mf4YL6fl8yqwuPqsyI9EmKdUfytVO6mqdC7EHwiES6KLNDNCC8K60QWYAof3AidW00A2GXMao2');
const express = require('express');
const app = express();
app.use(express.static('public'));
// Use body-parser to retrieve the raw body as a buffer
const bodyParser = require('body-parser');


const YOUR_DOMAIN = 'http://localhost:4242';

const endpointSecret = "whsec_527da38c56e06f79f6d8305a79be716848774ea7d40afca8c30092295b17842b";


app.post('/create-checkout-session', async (req, res) => {
  const session = await stripe.checkout.sessions.create({
    line_items: [
      {
        price_data: {
          currency: "hkd",
          unit_amount: 12000,
          product_data: {
            name: "house cleaning",
          },
        },
        quantity: 1,
      },
      {
        price_data: {
          currency: "hkd",
          unit_amount: 22000,
          product_data: {
            name: "catch cp",
          },
        },
        quantity: 2,
      },
      
    ],
    mode: 'payment',
    success_url: `${YOUR_DOMAIN}/success.html`,
    cancel_url: `${YOUR_DOMAIN}/cancel.html`,
  });

  res.redirect(303, session.url);
});

const fulfillOrder = (lineItems) => {
  // TODO: fill me in
  console.log("Fulfilling order", lineItems);
}

app.post('/webhook', bodyParser.raw({type: 'application/json'}), async (request, response) => {
  const payload = request.body;
  const sig = request.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(payload, sig, endpointSecret);
  } catch (err) {
    return response.status(400).send(`Webhook Error: ${err.message}`).end();
  }

  // Handle the checkout.session.completed event
  if (event.type === 'checkout.session.completed') {
    console.log("check event details",event.data.object.id)
    // Retrieve the session. If you require line items in the response, you may include them by expanding line_items.
    const sessionWithLineItems = await stripe.checkout.sessions.retrieve(
      event.data.object.id,
      {
        expand: ['line_items'],
      }
    );
    const lineItems = sessionWithLineItems.line_items;

    // Fulfill the purchase...
    fulfillOrder(lineItems);
  }

  response.status(200).end();
});

// app.post('/webhook', bodyParser.raw({type: 'application/json'}), (request, response) => {
//   const payload = request.body;

//   console.log("Got payload: " + payload);

//   response.status(200).end();
// });

app.listen(4242, () => console.log('Running on port 4242'));